/* eslint-disable max-len */
/* eslint-disable no-underscore-dangle */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AlertController, LoadingController, Platform, ToastController } from '@ionic/angular';
import { Storage } from '@ionic/storage-angular';
import { AppCoreService } from '../app-core-service/app-core.service';
import { CryptoService } from '../crypto/crypto.service';
import { HelperMethodsService } from '../helper-methods/helper-methods.service';
import { NetworkService } from '../network/network.service';
import { ScreenSizeService } from '../screen-size/screen-size.service';

/* A decorator that tells Angular that this service should be created by the root application injector. */
@Injectable({
  providedIn: 'root'
})

export class ApiService extends AppCoreService {

  /**
   * Creates an instance of ApiService.
   *
   *
   * @param platform
   *
   * @param http
   *
   * @param alertController
   *
   * @param toastController
   * @memberof ApiService
   */
  constructor(
    platform: Platform,
    http: HttpClient,
    alertController: AlertController,
    toastController: ToastController,
    loadingController: LoadingController,
    cryptoService: CryptoService,
    storage: Storage,
    helperMethods: HelperMethodsService,
    screenSizeService: ScreenSizeService,
    networkService: NetworkService) {
    super(platform, http, alertController, toastController, loadingController, cryptoService, storage, helperMethods, screenSizeService, networkService);
    this.dbInit();
    this.getInfo();
    this.getLanguageCode();
  }

}
