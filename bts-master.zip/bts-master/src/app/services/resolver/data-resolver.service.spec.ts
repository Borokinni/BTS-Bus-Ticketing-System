import { TestBed } from '@angular/core/testing';

import { DataResolverService } from './data-resolver.service';

describe('DataResolverService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DataResolverService = TestBed.get(DataResolverService);
    expect(service).toBeTruthy();
  });
});
