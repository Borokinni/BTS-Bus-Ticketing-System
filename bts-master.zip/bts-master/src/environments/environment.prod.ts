export const environment = {
  production: true,
  apiBaseUrl: '',
  appVerCode: '1.0',
  apiAuthentication: {
    username: 'admin',
    password: 'admin'
  },
  cryptoInfo: {
    keyId: 'test',
    salt: '4321',
    keySize: 256,
    iterations: 23,
    keys: 'UbfKIjpofcgPrFAgk46P+hNM/Hs=',
    iv: '12345678909876541234567890987654',
  },
  isPwa: true,
  isLocal: false,
  defaultImageUrl: ''
};
