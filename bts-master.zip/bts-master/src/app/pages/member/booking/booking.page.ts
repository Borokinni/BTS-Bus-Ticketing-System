import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '@app-environments/environment';
import { ApiService } from '@app-services/api/api.service';
import { DataService } from '@app-services/data/data.service';
import { HelperMethodsService } from '@app-services/helper-methods/helper-methods.service';
import { ScreenSizeService } from '@app-services/screen-size/screen-size.service';
import { AlertController, IonicModule, LoadingController, ModalController, NavController } from '@ionic/angular';


@Component({
  selector: 'app-booking',
  templateUrl: './booking.page.html',
  styleUrls: ['./booking.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule]
})
export class BookingPage implements OnInit {

  hasSelected = false;
  queryParams: Record<string, string> = {};
  tickersCount = Array(10).fill(0).map((x, i) => i + 1);
  isPwa = false;
  tickerSelected = null;

  constructor(
    public fb: UntypedFormBuilder,
    private router: Router,
    public navController: NavController,
    public screenSizeService: ScreenSizeService,
    public modalController: ModalController,
    private dataService: DataService,
    private helperMethods: HelperMethodsService,
    public loadingController: LoadingController,
    private api: ApiService,
    private activatedRoute: ActivatedRoute,
    public alertController: AlertController,
  ) {
    this.isPwa = environment.isPwa;
  }

  ngOnInit() {
    this.queryParams = this.activatedRoute.snapshot.queryParams;
  }

  selectTicker(ticker: number) {
    this.tickerSelected = ticker;
    // this.hasSelected = true;
  }

}
