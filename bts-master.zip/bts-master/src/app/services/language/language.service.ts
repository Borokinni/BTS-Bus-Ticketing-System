import { Injectable } from '@angular/core';
import { Language } from '@app-models/app.interface';
import { Storage } from '@capacitor/storage';
import { TranslateService } from '@ngx-translate/core';

const LNG_KEY = 'SELECTED_LANGUAGE';

@Injectable({
  providedIn: 'root'
})
export class LanguageService {

  private selected: Language;
  private defaultLanguage: Language = { name: 'English', code: 'en' };
  private readonly languages: ReadonlyArray<Language> = [
    { ...this.defaultLanguage }
    // Add more languages here
  ];

  constructor(private translate: TranslateService) {
    this.initialAppLanguage();
  }

  get getLanguages(): ReadonlyArray<Language> {
    return this.languages;
  }

  get getSelectedLanguage(): Language {
    return this.selected;
  }

  initialAppLanguage() {
    const language = this.defaultLanguage.code; // or use  this.translate.getBrowserLang();
    this.translate.setDefaultLang(language);

    Storage.get({ key: LNG_KEY }).then(res => {
      if (res.value != null) {
        const selectedLanguage: Language = JSON.parse(res.value);
        this.setLanguage(selectedLanguage);
      } else {
        this.setLanguage(this.defaultLanguage);
      }

    }).catch(err => {
      console.error(err);
      this.setLanguage(this.defaultLanguage);
    });

  }

  setLanguage(selectedLanguage: Language): Language {
    this.translate.use(selectedLanguage.code);
    Storage.set({ key: LNG_KEY, value: JSON.stringify(selectedLanguage) });
    this.selected = selectedLanguage;

    return selectedLanguage;
  }

}
