import { Routes } from '@angular/router';

export const pubicRoutes: Routes = [

  {
    path: 'public',
    title: 'Public',
    children: [
      {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full',
      },
      {
        path: 'login',
        title: 'Login',
        loadComponent: () => import('./login/login.page').then(m => m.LoginPage)
      },
      {
        path: 'register',
        title: 'Register',
        loadComponent: () => import('./register/register.page').then(m => m.RegisterPage)
      }
    ]
  }
];
