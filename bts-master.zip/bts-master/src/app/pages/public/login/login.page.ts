import { CommonModule } from '@angular/common';
import { Component, HostListener, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PasswordStrengthComponent } from '@app-components/password-strength/password-strength.component';
import { environment } from '@app-environments/environment';
import { ApiService } from '@app-services/api/api.service';
import { DataService } from '@app-services/data/data.service';
import { FormValidatorService } from '@app-services/form-validator/form-validator.service';
import { HelperMethodsService } from '@app-services/helper-methods/helper-methods.service';
import { ScreenSizeService } from '@app-services/screen-size/screen-size.service';
import { AlertController, IonicModule, LoadingController, ModalController, NavController } from '@ionic/angular';
import { passwordStrength } from 'check-password-strength';
import { NetworkService } from '@app-services/network/network.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule, PasswordStrengthComponent]
})
export class LoginPage implements OnInit {

  isPwa = false;
  isDesktop = true;
  userLoginForm!: UntypedFormGroup;
  user: any = {
    email: !environment.production ? 'danstevea@gmail.com' : '',
    password: !environment.production ? 'password' : '',
  };
  seePassword = false;
  queryParams: Record<string, string> = {};

  constructor(
    public fb: UntypedFormBuilder,
    private router: Router,
    public navController: NavController,
    public screenSizeService: ScreenSizeService,
    public modalController: ModalController,
    private dataService: DataService,
    private helperMethods: HelperMethodsService,
    public loadingController: LoadingController,
    private api: ApiService,
    private activatedRoute: ActivatedRoute,
    public alertController: AlertController,
    private networkService: NetworkService,
  ) {
    this.isPwa = environment.isPwa;
  }

  ngOnInit() {
    this.networkService.initializeNetworkSubscription();
    this.userLoginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email, FormValidatorService.emailValidator]],
      password: ['', [Validators.required,]],
    });
    this.userLoginForm.get('password').valueChanges.subscribe(val => {
      this.user.passwordStrength = passwordStrength(val);
    });
  }

  /**
 * ionViewWillEnter/ to call after component/page enter
 */
  ionViewWillEnter() {
    this.isPwa = environment.isPwa;
    this.screenSizeService.isDesktop.subscribe(isDesktop => {
      if (this.isDesktop && !isDesktop) {
        // Reload because our routing is out of place
        // window.location.reload();
      }
      this.isDesktop = true;
    });
    this.api.getLocalData('config_meta').then((data) => {
      this.user.email = null || data.email;
      this.user.password = null;
    }).catch(async (err) => console.log(err));
  }

  @HostListener('window:resize', ['$event',])
  redoResize(event: any) {
    this.screenSizeService.onResize(event.target.innerWidth, event.target.innerHeight);
    console.log(event.target);
  }


  /**
   * Toggle password see state
   */
  showPassword() {
    this.seePassword = !this.seePassword;
  }

  /**
 * goTo a url
 */
  goTo(url: string) {
    const convertJsonToUrlParam = `${this.helperMethods.convertJsonToUrlParam(this.queryParams)}`;
    const urlParam = convertJsonToUrlParam.length > 0 ? `?${convertJsonToUrlParam}` : '';

    this.navController.navigateRoot(url + urlParam);
  }

  /**
 * Enter to submit form
 */
  enterSubmit(event: KeyboardEvent): void {
    if (event) {
      if (event.keyCode === 13 || event?.code?.toLowerCase() === 'enter') {
        this.login();
      }
    }
  }

  login() {
    this.goTo('member/dashboard');
  }
}
