/* eslint-disable max-len */
import { Injectable } from '@angular/core';
import { CreateMiCampaignComponent } from '@app-components//plans/create-mi-campaign/create-mi-campaign.component';
import { CreateMiHalalComponent } from '@app-components//plans/create-mi-halal/create-mi-halal.component';
import { CreateMiLockComponent } from '@app-components//plans/create-mi-lock/create-mi-lock.component';
import { CreateMiSafeComponent } from '@app-components//plans/create-mi-safe/create-mi-safe.component';
import { CreateMiTargetComponent } from '@app-components//plans/create-mi-target/create-mi-target.component';
import { CreateMiTrybeComponent } from '@app-components//plans/create-mi-trybe/create-mi-trybe.component';
import { PlanRolloverComponent } from '@app-components/plans/plan-rollover/plan-rollover.component';
import { WalletRolloverComponent } from '@app-components/wallet/wallet-rollover/wallet-rollover.component';
import { ReferralPage } from '@app-pages/member/referral/referral.page';

@Injectable({
  providedIn: 'root'
})
export class ComponentPickerService {

  componentsList: Array<any> = [
    ReferralPage,
    PlanRolloverComponent,
    WalletRolloverComponent,
    CreateMiCampaignComponent,
    CreateMiHalalComponent,
    CreateMiLockComponent,
    CreateMiSafeComponent,
    CreateMiTargetComponent,
    CreateMiTrybeComponent
  ];

  componentsListName = [];
  constructor() {
    this.componentsList.forEach((x) => {
      this.componentsListName.push(x.prototype.getClassName());
    });
  }

  getComponent(componentName: string = '') {
    componentName = componentName.includes('Component') ? componentName : componentName + 'Component';
    let component = null;
    const index = this.componentsListName.findIndex(x => x === componentName);
    if (index !== -1) {
      component = this.componentsList[index];
    }
    return component;
  }

}
