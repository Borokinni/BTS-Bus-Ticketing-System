import moment from 'moment';

/** Returns the current date and time formatted as [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601).  */
export const timestamp = (): any => moment().toISOString();

/** Returns true of `input` is a valid [ISO 8601](https://en.wikipedia.org/wiki/ISO_8601) string. */
export const isISOString = (input: unknown): boolean => moment(input, moment.ISO_8601).isValid();
