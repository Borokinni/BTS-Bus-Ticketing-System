import { Routes } from '@angular/router';

export const memberRoutes: Routes = [
  {
    path: 'member',
    title: 'Member',
    children: [
      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full',
      },
      {
        path: 'dashboard',
        title: 'Dashboard',
        loadComponent: () => import('./dashboard/dashboard.page').then(m => m.DashboardPage)
      },
      {
        path: 'booking',
        title: 'Booking',
        loadComponent: () => import('./booking/booking.page').then(m => m.BookingPage)
      },
      {
        path: 'payment',
        title: 'Payment',
        loadComponent: () => import('./payment/payment.page').then(m => m.PaymentPage)
      },
    ]
  }
];
