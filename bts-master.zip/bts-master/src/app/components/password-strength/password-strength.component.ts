import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
// import { IonProgressBar } from '@ionic/angular/standalone';

@Component({
  selector: 'app-password-strength',
  templateUrl: './password-strength.component.html',
  styleUrls: ['./password-strength.component.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ReactiveFormsModule]
})
export class PasswordStrengthComponent implements OnInit {

  @Input() passwordStrength = {
    id: 0,
    value: 'Too weak',
    minDiversity: 0,
    minLength: 0
  };

  constructor() { }

  /**
   * Init method/function to be call on  load of component/page
   */
  ngOnInit() {
  }

}
