import { Routes } from '@angular/router';
import { pubicRoutes } from './pages/public/public.routes';
import { memberRoutes } from './pages/member/member.routes';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'public',
    pathMatch: 'full',
  },
  ...pubicRoutes,
  ...memberRoutes
];
