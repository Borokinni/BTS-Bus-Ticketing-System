/* eslint-disable no-underscore-dangle */
export class Logger {

  private release = false;
  private platform = 'browser';
  private _console: any = console;

  public setReleaseStatus(status: boolean) {
    this.release = status;
  }

  public setPlatform(platform: string) {
    this.platform = platform;
  }

  public debug(...message: any[]): void {
    return this.logWith('info', message);
  }

  public warn(...message: any[]): void {
    return this.logWith('warn', message);
  }

  public error(...message: any[]): void {
    return this.logWith('error', message);
  }

  public log(...message: any[]): void {
    return this.logWith('log', message);
  }

  public logWith(severity = 'log', messages: any): void {
    if (this.platform === 'adb') {
      // tslint:disable-next-line:no-parameter-reassignment
      messages = messages.map((m: any) => JSON.stringify(m));
    }

    if (!this.release) {
      this.getLoggerFunction(severity).apply(this._console, messages);
    }
  }

  private getLoggerFunction(level: string) {
    // tslint:disable:no-unbound-method
    switch (level) {
      case 'info':
        return this._console.info;
      case 'debug':
        return this._console.debug;
      case 'warn':
        return this._console.warn;
      case 'error':
        return this._console.error;
      default:
        return this._console.log;
    }
  }
}
